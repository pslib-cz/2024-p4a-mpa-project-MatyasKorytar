package com.example.project

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {
    private val taskDao: TaskDao = AppDatabase.getDatabase(application).taskDao()
    val allTasks: LiveData<List<Task>> = taskDao.getAllTasks()

    // Přidání úkolu
    fun insert(task: Task) = viewModelScope.launch {
        taskDao.insert(task)
    }

    // Smazání úkolu
    fun delete(task: Task) = viewModelScope.launch {
        taskDao.delete(task)
    }

    // Aktualizace úkolu
    fun update(task: Task) = viewModelScope.launch {
        taskDao.update(task)
    }
}
