package com.example.project

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: TaskViewModel
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializace ViewModelu
        viewModel = ViewModelProvider(this).get(TaskViewModel::class.java)

        // Inicializace RecyclerView
        adapter = TaskAdapter { task -> viewModel.delete(task) }
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Pozorování změn v seznamu úkolů
        viewModel.allTasks.observe(this) { tasks ->
            adapter.submitList(tasks) // Dynamické aktualizování seznamu úkolů
        }

        // Přidání úkolu pomocí tlačítka
        val addButton: Button = findViewById(R.id.addButton)
        val taskInput: EditText = findViewById(R.id.taskInput)

        addButton.setOnClickListener {
            val title = taskInput.text.toString()
            if (title.isNotBlank()) {
                viewModel.insert(Task(title = title, description = "Popis úkolu")) // Přidání nového úkolu
                taskInput.text.clear() // Vyčištění vstupu
            }
        }
    }
}

